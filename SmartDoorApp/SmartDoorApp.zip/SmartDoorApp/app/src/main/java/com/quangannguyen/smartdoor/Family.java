package com.quangannguyen.smartdoor;

/**
 * Created by quangannguyen on 2/22/2018.
 */

public class Family {

    private String check_family;

    public Family() {
    }

    public Family(String check_family) {
        this.check_family = check_family;
    }

    public String getCheck_family() {
        return check_family;
    }

    public void setCheck_family(String check_family) {
        this.check_family = check_family;
    }
}
